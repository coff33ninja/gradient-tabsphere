# Dashboard UI #1 : Project management with Charts

A Pen created on CodePen.io. Original URL: [https://codepen.io/olsiodobashi/pen/BLBdgr](https://codepen.io/olsiodobashi/pen/BLBdgr).

Basic project management dashboard. This particular view shows the list of all the projects and some basic info, like who's the PM, has the project been started yet, is there any items that require urgent action to be taken, etc.
On the right side there's also an Actions dropdown, which gives the admins (like the Product Owner) a quick set of actions, like "Start project", "Send an invoice", etc.