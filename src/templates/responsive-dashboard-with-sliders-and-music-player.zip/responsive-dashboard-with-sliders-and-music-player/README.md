# Responsive Dashboard with Sliders and Music Player

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/MWxjXeq](https://codepen.io/ecemgo/pen/MWxjXeq).

This pen has a responsive dashboard with sliders and a built-in music player. With the music player, you can easily skip songs or play them on a loop. Plus, each song comes with its album cover, and there's a record player effect with a rotating animation. And when you explore the artists, albums, and songs sections, each image has a hover effect. This pen is all about making the dashboard fun!

Inspired by https://dribbble.com/shots/16104275-Podcast-dashboard-design-light

🎵 Music Credit:
1) Besomorph & Coopex - Redemption (ft. Riell) [NCS Release]
2) OSKI - What's The Problem? [NCS Release]
3) Unknown Brain x Rival - Control (feat. Jex) [NCS Release]
Music provided by NoCopyrightSounds

The other responsive dashboards: 
1) https://codepen.io/ecemgo/pen/rNbLodN
2) https://codepen.io/ecemgo/pen/YzBZjjb
